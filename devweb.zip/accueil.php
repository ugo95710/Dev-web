<html>
<body>
    <form action="authentification.php" method="post">

        <label>Login</label>
        <input type="email" placeholder="Entrer votre identifiant" name="id"><br>

        <label>Mot de passe</label>
        <input type="text" placeholder="Entrer votre mot de passe" name="mdp"><br>
        
        <input type="submit" value="Envoyez">  
        

    </form>
    <form action="creation.php" method="post">

        <input type="submit" value="creer un compte"><br>
        
    </form>
</body>
</html>